module.exports = {
  preset: "ts-jest",
  testEnvironment: "node",
  testMatch: ["**/src/__tests__/**/*.test.ts"],
  collectCoverage: process.env.CI ? true : false,
  coverageReporters: ["clover"],
  coverageDirectory: "src/__tests__/coverage",
  collectCoverageFrom: ["src/**/*.ts", "!**/__tests__/**/*"],
};
